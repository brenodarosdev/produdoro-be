package dev.wakandaacademy.produdoro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdudoroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdudoroApplication.class, args);
	}

}
